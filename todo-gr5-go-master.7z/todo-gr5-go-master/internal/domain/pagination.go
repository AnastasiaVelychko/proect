package domain

type Pagination struct {
	Page         uint64
	CountPerPage uint64
}
